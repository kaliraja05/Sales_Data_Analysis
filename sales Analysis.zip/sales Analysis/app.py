import streamlit as st
import pandas as pd
import plotly.express as px

# ======================================================
# Page Configuration
# ======================================================
st.set_page_config(
    page_title="Sales Data Visualization Dashboard",
    page_icon="📊",
    layout="wide"
)

st.title("📊 Sales Data Visualization Dashboard")
st.markdown("---")

# ======================================================
# Load Data
# ======================================================
@st.cache_data
def load_data():
    df = pd.read_csv("sales_data.csv")

    # Remove spaces from column names
    df.columns = df.columns.str.strip()

    # Convert Date
    df["Sale_Date"] = pd.to_datetime(
    df["Sale_Date"],
    format="mixed",
    dayfirst=True,
    errors="coerce"
)

    # Month & Year
    df["Month"] = df["Sale_Date"].dt.strftime("%B")
    df["Year"] = df["Sale_Date"].dt.year

    # Estimated Profit
    df["Profit"] = (
        (df["Unit_Price"] - df["Unit_Cost"])
        * df["Quantity_Sold"]
    )

    return df


df = load_data()

# ======================================================
# Sidebar Filters
# ======================================================
st.sidebar.header("🔍 Filters")

regions = st.sidebar.multiselect(
    "Region",
    sorted(df["Region"].unique()),
    default=sorted(df["Region"].unique())
)

categories = st.sidebar.multiselect(
    "Category",
    sorted(df["Product_Category"].unique()),
    default=sorted(df["Product_Category"].unique())
)

sales_rep = st.sidebar.multiselect(
    "Sales Representative",
    sorted(df["Sales_Rep"].unique()),
    default=sorted(df["Sales_Rep"].unique())
)

months = st.sidebar.multiselect(
    "Month",
    sorted(df["Month"].unique()),
    default=sorted(df["Month"].unique())
)

# ======================================================
# Filter Data
# ======================================================
filtered = df[
    (df["Region"].isin(regions)) &
    (df["Product_Category"].isin(categories)) &
    (df["Sales_Rep"].isin(sales_rep)) &
    (df["Month"].isin(months))
]

# ======================================================
# KPI Cards
# ======================================================
total_sales = filtered["Sales_Amount"].sum()
total_profit = filtered["Profit"].sum()
total_orders = filtered["Product_ID"].count()
avg_sales = filtered["Sales_Amount"].mean()

col1, col2, col3, col4 = st.columns(4)

col1.metric(
    "💰 Total Sales",
    f"₹{total_sales:,.2f}"
)

col2.metric(
    "📈 Estimated Profit",
    f"₹{total_profit:,.2f}"
)

col3.metric(
    "📦 Total Orders",
    total_orders
)

col4.metric(
    "💵 Average Sale",
    f"₹{avg_sales:,.2f}"
)

st.markdown("---")

# ======================================================
# Region-wise Sales
# ======================================================
col1, col2 = st.columns(2)

with col1:

    region_sales = (
        filtered.groupby("Region")["Sales_Amount"]
        .sum()
        .reset_index()
    )

    fig = px.bar(
        region_sales,
        x="Region",
        y="Sales_Amount",
        color="Region",
        text_auto=".2s",
        title="🌍 Region-wise Sales"
    )

    st.plotly_chart(fig, use_container_width=True)

# ======================================================
# Monthly Sales Trend
# ======================================================
with col2:

    month_sales = (
        filtered.groupby("Month")["Sales_Amount"]
        .sum()
        .reset_index()
    )

    fig = px.line(
        month_sales,
        x="Month",
        y="Sales_Amount",
        markers=True,
        title="📈 Monthly Sales Trend"
    )

    st.plotly_chart(fig, use_container_width=True)

# ======================================================
# Category Pie Chart
# ======================================================
col3, col4 = st.columns(2)

with col3:

    fig = px.pie(
        filtered,
        names="Product_Category",
        values="Sales_Amount",
        hole=0.4,
        title="🥧 Sales by Category"
    )

    st.plotly_chart(fig, use_container_width=True)

# ======================================================
# Sales by Sales Representative
# ======================================================
with col4:

    rep_sales = (
        filtered.groupby("Sales_Rep")["Sales_Amount"]
        .sum()
        .reset_index()
    )

    fig = px.bar(
        rep_sales,
        x="Sales_Rep",
        y="Sales_Amount",
        color="Sales_Rep",
        text_auto=".2s",
        title="👨‍💼 Sales by Representative"
    )

    st.plotly_chart(fig, use_container_width=True)

# ======================================================
# Payment Method
# ======================================================
col5, col6 = st.columns(2)

with col5:

    payment = (
        filtered.groupby("Payment_Method")["Sales_Amount"]
        .sum()
        .reset_index()
    )

    fig = px.bar(
        payment,
        x="Payment_Method",
        y="Sales_Amount",
        color="Payment_Method",
        title="💳 Payment Method Analysis"
    )

    st.plotly_chart(fig, use_container_width=True)

# ======================================================
# Customer Type
# ======================================================
with col6:

    customer = (
        filtered.groupby("Customer_Type")["Sales_Amount"]
        .sum()
        .reset_index()
    )

    fig = px.pie(
        customer,
        names="Customer_Type",
        values="Sales_Amount",
        title="🧑 Customer Type Analysis"
    )

    st.plotly_chart(fig, use_container_width=True)

# ======================================================
# Top 10 Products
# ======================================================
st.markdown("---")

top_products = (
    filtered.groupby("Product_ID")["Sales_Amount"]
    .sum()
    .reset_index()
    .sort_values(by="Sales_Amount", ascending=False)
    .head(10)
)

fig = px.bar(
    top_products,
    x="Product_ID",
    y="Sales_Amount",
    color="Sales_Amount",
    text_auto=".2s",
    title="🏆 Top 10 Products"
)

st.plotly_chart(fig, use_container_width=True)

# ======================================================
# Data Table
# ======================================================
st.markdown("---")

st.subheader("📋 Filtered Sales Data")

st.dataframe(
    filtered,
    use_container_width=True,
    hide_index=True
)

# ======================================================
# Download CSV
# ======================================================
csv = filtered.to_csv(index=False).encode("utf-8")

st.download_button(
    label="📥 Download Filtered Data",
    data=csv,
    file_name="filtered_sales_data.csv",
    mime="text/csv"
)

# ======================================================
# Footer
# ======================================================
st.markdown("---")

st.caption("📊 Sales Dashboard | Python • Pandas • Streamlit • Plotly")