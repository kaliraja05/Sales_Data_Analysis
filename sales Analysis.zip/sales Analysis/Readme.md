# 📊 Sales Data Visualization Dashboard

A simple and interactive **Sales Data Visualization Dashboard** built using **Python, Pandas, Streamlit, and Plotly**. This project helps analyze sales data through interactive charts, KPI cards, and filters.

---

## 🚀 Features

* 📊 Interactive Dashboard
* 🌍 Filter data by Region
* 📂 Filter data by Product Category
* 👨‍💼 Filter data by Sales Representative
* 📅 Filter data by Month
* 💰 Total Sales KPI
* 📈 Estimated Profit KPI
* 📦 Total Orders KPI
* 💵 Average Sales KPI
* 📊 Region-wise Sales Bar Chart
* 📈 Monthly Sales Trend Line Chart
* 🥧 Category-wise Sales Pie Chart
* 👨‍💼 Sales by Representative Chart
* 💳 Payment Method Analysis
* 👥 Customer Type Analysis
* 🏆 Top 10 Products Chart
* 📥 Download Filtered Data as CSV

---

## 🛠️ Technologies Used

* Python
* Pandas
* Streamlit
* Plotly Express
* OpenPyXL

---

## 📁 Project Structure

```text
Sales_Data_Visualization_Dashboard/
│
├── app.py
├── sales_data.csv
├── requirements.txt
└── README.md
```

---

## 📦 Installation

Clone the repository:

```bash
git clone <repository-url>
```

Move into the project folder:

```bash
cd Sales_Data_Visualization_Dashboard
```

Install the required libraries:

```bash
pip install -r requirements.txt
```

Or install manually:

```bash
pip install streamlit pandas plotly openpyxl
```

---

## ▶️ Run the Project

```bash
streamlit run app.py
```

If `streamlit` is not added to your PATH:

```bash
py -m streamlit run app.py
```

---

## 📊 Dashboard Modules

* Sales Summary
* Interactive Filters
* KPI Cards
* Region-wise Sales
* Monthly Sales Trend
* Product Category Analysis
* Sales Representative Analysis
* Payment Method Analysis
* Customer Type Analysis
* Top 10 Products
* Filtered Data Table
* CSV Download

---

## 📈 KPIs

* Total Sales
* Estimated Profit
* Total Orders
* Average Sales

---

## 📚 What I Learned

* Reading CSV files using Pandas
* Cleaning and preprocessing data
* Handling date formats
* Creating interactive dashboards with Streamlit
* Building charts using Plotly
* Using filters for data analysis
* Calculating business KPIs
* Exporting filtered data to CSV
* Debugging common Python and Pandas errors

---

## 🎯 Future Enhancements

* Add Login Authentication
* Connect with MySQL Database
* Real-time Sales Dashboard
* Predict Future Sales using Machine Learning
* Export Reports as PDF and Excel
* Dark Mode Dashboard

---

## 👨‍💻 Author

**Kaliraja N**

---

## 📄 License

This project is developed for educational and learning purposes.
